function X=A_adj(z,Acell,m);
[n1,n2] = size(Acell{1});
X=zeros(n1,n2);
for itt=1:m
    X=X+z(itt)*Acell{itt};
end 
end
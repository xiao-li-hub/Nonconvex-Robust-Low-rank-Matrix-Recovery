% code for ''Nonconvex Robust Low-rank Matrix Recovery'', Xiao Li, 
%Zhihui Zhu, Anthony Man-Cho So, Rene Vidal. Available at https://arxiv.org/abs/1809.09237

%If you find the code usful, please cite our paper. 



clear all; close all;
rand('seed',2018);randn('seed',2018);
%addpath('export_fig')
n=50;  
r = 5;
m = 5*n*r;
p_fail = 0.3;

Uo=randn(n,r);
X=Uo*Uo';
%sensing
y=zeros(m,1); Acell=cell(m,1);
for it=1:m
    Acell{it}=randn(n,n);
    y(it)=trace(X'*Acell{it});
end
%add outliers
s = zeros(m,1);
indx = randperm(m);
s(indx(1:floor(p_fail*m))) = 10*randn(floor(p_fail*m),1);
%observation
y = y + s;

Aop=zeros(m,n^2);
for it=1:m
    Aop(it,:)=vec(Acell{it})';
end





% algorithm parameter
maxiter = 1e3;
%mu_0 = 1e-3; rho = 0.98;
mu_0 = 1/m; rho = 0.95;
%random initialization
U_0 = randn(n,r); U = U_0;
dist_ed = [];dist_ed(1) = norm(U*U' - X,'fro');

%SubGM loop
for i = 2:maxiter+1
    dev=Aop*vec(U*U')-y;
    gradU = (A_adj(sign(dev),Acell,m)*U) + (A_adj(sign(dev),Acell,m)'*U);
    mu = mu_0*rho^i;
    U = U - mu*gradU;
 %   dist_ed(i) = norm(U*U' - X,'fro');
    
    [P S Q] = svd(U'*Uo);
    dist_ed(i) = norm(U - Uo*Q*P','fro');
end

           
% plot 
figure(1)
semilogy(dist_ed,'LineWidth',2);
xlim([0 1e3])
ylim([1e-15 100])
set(gca, 'LineWidth' , 1.8,'FontSize',20);
set(gcf, 'Color', 'w');
xlabel('Iteration','FontSize',22);
ylabel('dist$({\bf U}_k, {\cal U})$','FontSize',22,'FontName', 'Times New Roman','Interpreter','LaTex');



